//
//  ViewController.swift
//  Maiegg
//
//  Created by PAULO JANSEN DE OLIVEIRA FIGUEIREDO on 16/04/2018.
//  Copyright © 2018 PAULO JANSEN DE OLIVEIRA FIGUEIREDO. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

