//
//  Keyboard1.h
//  CustomKeyboard
//
//  Created by RAFAEL FIORAMONTE on 19/10/17.
//  Copyright © 2017 MARCELO DIB COUTINHO. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Keyboard1 : UIInputView
@property (weak, nonatomic) IBOutlet UIButton *globeKey;
@property (weak, nonatomic) IBOutlet UIButton *Comida;
@property (weak, nonatomic) IBOutlet UIButton *Lazer;
@property (weak, nonatomic) IBOutlet UIButton *Passeios;
@property (weak, nonatomic) IBOutlet UIButton *Sentimentos;

@end
