//
//  KeyboardViewController.h
//  MyKeyboard
//
//  Created by MARCELO DIB COUTINHO on 18/10/17.
//  Copyright © 2017 MARCELO DIB COUTINHO. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeyboardViewController : UIInputViewController

@end
