//
//  TecladoPasseios.h
//  CustomKeyboard
//
//  Created by RAFAEL FIORAMONTE on 19/10/17.
//  Copyright © 2017 MARCELO DIB COUTINHO. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TecladoPasseios : UIInputView
@property (weak, nonatomic) IBOutlet UIButton *Carro;
@property (weak, nonatomic) IBOutlet UIButton *Bicicleta;
@property (weak, nonatomic) IBOutlet UIButton *PasseioDeMae;
@property (weak, nonatomic) IBOutlet UIButton *Aviao;

@end
