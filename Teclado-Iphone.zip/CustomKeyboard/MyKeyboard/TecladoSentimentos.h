//
//  TecladoSentimentos.h
//  CustomKeyboard
//
//  Created by RAFAEL FIORAMONTE on 19/10/17.
//  Copyright © 2017 MARCELO DIB COUTINHO. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TecladoSentimentos : UIInputView
@property (weak, nonatomic) IBOutlet UIButton *Feliz;
@property (weak, nonatomic) IBOutlet UIButton *Triste;
@property (weak, nonatomic) IBOutlet UIButton *Dor;
@property (weak, nonatomic) IBOutlet UIButton *Enjoado;

@end
