//
//  Keyboard2.m
//  CustomKeyboard
//
//  Created by MARCELO DIB COUTINHO on 18/10/17.
//  Copyright © 2017 MARCELO DIB COUTINHO. All rights reserved.
//

#import "Keyboard2.h"

@implementation Keyboard2

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
