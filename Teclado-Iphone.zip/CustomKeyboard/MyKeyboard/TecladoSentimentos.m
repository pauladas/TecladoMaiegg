//
//  TecladoSentimentos.m
//  CustomKeyboard
//
//  Created by RAFAEL FIORAMONTE on 19/10/17.
//  Copyright © 2017 MARCELO DIB COUTINHO. All rights reserved.
//

#import "TecladoSentimentos.h"

@implementation TecladoSentimentos

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
