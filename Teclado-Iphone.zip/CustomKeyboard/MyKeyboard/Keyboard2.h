//
//  Keyboard2.h
//  CustomKeyboard
//
//  Created by MARCELO DIB COUTINHO on 18/10/17.
//  Copyright © 2017 MARCELO DIB COUTINHO. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Keyboard2 : UIInputView
@property (weak, nonatomic) IBOutlet UIButton *Pizza;
@property (weak, nonatomic) IBOutlet UIButton *Hamburguer;
@property (weak, nonatomic) IBOutlet UIButton *Sorvete;
@property (weak, nonatomic) IBOutlet UIButton *Refrigerante;

@end
