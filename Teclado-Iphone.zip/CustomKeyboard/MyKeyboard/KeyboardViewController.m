//
//  KeyboardViewController.m
//  MyKeyboard
//
//  Created by MARCELO DIB COUTINHO on 18/10/17.
//  Copyright © 2017 MARCELO DIB COUTINHO. All rights reserved.
//

#import "KeyboardViewController.h"
#import "Keyboard1.h"
#import "Keyboard2.h"
#import "Keyboard3.h"
#import "TecladoPasseios.h"
#import "TecladoSentimentos.h"


@interface KeyboardViewController ()
@property (strong, nonatomic) Keyboard1 *keyboard1;
@property (strong, nonatomic) Keyboard2 *keyboard2;
@property (strong, nonatomic) Keyboard3 *keyboard3;
@property (strong, nonatomic) TecladoPasseios *tecladopasseios;
@property (strong, nonatomic) TecladoSentimentos *tecladosentimentos;

@end

@implementation KeyboardViewController

- (void)updateViewConstraints {
    [super updateViewConstraints];
    
    // Add custom view sizing constraints here
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Perform custom UI setup here
    
    self.keyboard1 = [[[NSBundle mainBundle] loadNibNamed:@"Keyboard1" owner:nil options:nil]objectAtIndex:0];
    
    self.keyboard2 = [[[NSBundle mainBundle] loadNibNamed:@"Keyboard2" owner:nil options:nil]objectAtIndex:0];
    
    self.keyboard3 = [[[NSBundle mainBundle] loadNibNamed:@"Keyboard3" owner:nil options:nil]objectAtIndex:0];
    
    self.tecladopasseios = [[[NSBundle mainBundle] loadNibNamed:@"TecladoPasseios" owner:nil options:nil]objectAtIndex:0];
    
    self.tecladosentimentos = [[[NSBundle mainBundle] loadNibNamed:@"TecladoSentimentos" owner:nil options:nil]objectAtIndex:0];
    

    
    [self addGesturesToKeyboard];
    self.inputView = self.keyboard1;
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated
}

- (void)textWillChange:(id<UITextInput>)textInput {
    // The app is about to change the document's contents. Perform any preparation here.
}

- (void)textDidChange:(id<UITextInput>)textInput {
    // The app has just changed the document's contents, the document context has been updated.
    
    UIColor *textColor = nil;
    if (self.textDocumentProxy.keyboardAppearance == UIKeyboardAppearanceDark) {
        textColor = [UIColor whiteColor];
    } else {
        textColor = [UIColor blackColor];
    }
    
}

#pragma mark Keyboards
- (void) addGesturesToKeyboard{
    //Change to next keyboard
    
    [self.keyboard1.globeKey addTarget:self action:@selector(advanceToNextInputMode) forControlEvents: UIControlEventTouchUpInside];
    
    [self.keyboard2.Pizza addTarget:self action:@selector(PizzaAction) forControlEvents: UIControlEventTouchUpInside];
    [self.keyboard2.Hamburguer addTarget:self action:@selector(HamburguerAction) forControlEvents: UIControlEventTouchUpInside];
    [self.keyboard2.Sorvete addTarget:self action:@selector(SorveteAction) forControlEvents: UIControlEventTouchUpInside];
    [self.keyboard2.Refrigerante addTarget:self action:@selector(RefrigeranteAction) forControlEvents: UIControlEventTouchUpInside];
    
    
    
    [self.keyboard3.Bola addTarget:self action:@selector(BolaAction) forControlEvents: UIControlEventTouchUpInside];
    [self.keyboard3.Computador addTarget:self action:@selector(ComputadorAction) forControlEvents: UIControlEventTouchUpInside];
    [self.keyboard3.Televisao addTarget:self action:@selector(TelevisaoAction) forControlEvents: UIControlEventTouchUpInside];
    [self.keyboard3.VideoGame addTarget:self action:@selector(VideoGameAction) forControlEvents: UIControlEventTouchUpInside];
    
    
    
    [self.tecladopasseios.Carro addTarget:self action:@selector(CarroAction) forControlEvents: UIControlEventTouchUpInside];
    [self.tecladopasseios.Bicicleta addTarget:self action:@selector(BicicletaAction) forControlEvents: UIControlEventTouchUpInside];
    [self.tecladopasseios.PasseioDeMae addTarget:self action:@selector(PasseioDeMaeAction) forControlEvents: UIControlEventTouchUpInside];
    [self.tecladopasseios.Aviao addTarget:self action:@selector(AviaoAction) forControlEvents: UIControlEventTouchUpInside];
    
    
    
    [self.tecladosentimentos.Feliz addTarget:self action:@selector(FelizAction) forControlEvents: UIControlEventTouchUpInside];
    [self.tecladosentimentos.Triste addTarget:self action:@selector(TristeAction) forControlEvents: UIControlEventTouchUpInside];
    [self.tecladosentimentos.Dor addTarget:self action:@selector(DorAction) forControlEvents: UIControlEventTouchUpInside];
    [self.tecladosentimentos.Enjoado addTarget:self action:@selector(EnjoadoAction) forControlEvents: UIControlEventTouchUpInside];
    
    
    
    [self.keyboard1.Comida addTarget:self action:@selector(ComidaView) forControlEvents: UIControlEventTouchUpInside];
    [self.keyboard1.Lazer addTarget:self action:@selector(LazerView) forControlEvents: UIControlEventTouchUpInside];
    [self.keyboard1.Passeios addTarget:self action:@selector(PasseioView) forControlEvents: UIControlEventTouchUpInside];
    [self.keyboard1.Sentimentos addTarget:self action:@selector(SentimentosView) forControlEvents: UIControlEventTouchUpInside];
}

- (void)pressChangeScreen {
    [self.textDocumentProxy insertText:@"potato"];
    self.inputView = self.keyboard2;
}
- (void)pressBatata {
    [self.textDocumentProxy insertText:@"meu ovo"];
    self.inputView = self.keyboard3;
}

- (void)pressButton {
    [self.textDocumentProxy insertText:@"meu button"];
    self.inputView = self.keyboard1;
}

- (void)ComidaView {
    self.inputView = self.keyboard2;
}
- (void)LazerView {
    self.inputView = self.keyboard3;
}
- (void)PasseioView {
    self.inputView = self.tecladopasseios;
}
- (void)SentimentosView {
    self.inputView = self.tecladosentimentos;
}

- (void)PizzaAction {
    [self.textDocumentProxy insertText:@"Eu quero comer pizza"];
    self.inputView = self.keyboard1;
}
- (void)HamburguerAction {
    [self.textDocumentProxy insertText:@"Eu quero comer hambúrguer"];
    self.inputView = self.keyboard1;
}
- (void)SorveteAction {
    [self.textDocumentProxy insertText:@"Eu quero tomar sorvete"];
    self.inputView = self.keyboard1;
}
- (void)RefrigeranteAction {
    [self.textDocumentProxy insertText:@"Eu quero beber refrigerante"];
    self.inputView = self.keyboard1;
}

- (void)BolaAction {
    [self.textDocumentProxy insertText:@"Eu quero jogar bola"];
    self.inputView = self.keyboard1;
}
- (void)ComputadorAction {
    [self.textDocumentProxy insertText:@"Eu quero usar o computador"];
    self.inputView = self.keyboard1;
}
- (void)TelevisaoAction {
    [self.textDocumentProxy insertText:@"Eu quero ver televisão"];
    self.inputView = self.keyboard1;
}
- (void)VideoGameAction {
    [self.textDocumentProxy insertText:@"Eu quero jogar video game"];
    self.inputView = self.keyboard1;
}

- (void)CarroAction {
    [self.textDocumentProxy insertText:@"Eu quero andar de carro"];
    self.inputView = self.keyboard1;
}
- (void)BicicletaAction {
    [self.textDocumentProxy insertText:@"Eu quero andar de bicicleta"];
    self.inputView = self.keyboard1;
}
- (void)PasseioDeMaeAction {
    [self.textDocumentProxy insertText:@"Eu quero passear"];
    self.inputView = self.keyboard1;
}
- (void)AviaoAction {
    [self.textDocumentProxy insertText:@"Eu quero viajar"];
    self.inputView = self.keyboard1;
}

- (void)FelizAction {
    [self.textDocumentProxy insertText:@"Eu estou feliz"];
    self.inputView = self.keyboard1;
}
- (void)TristeAction {
    [self.textDocumentProxy insertText:@"Eu estou triste"];
    self.inputView = self.keyboard1;
}
- (void)DorAction {
    [self.textDocumentProxy insertText:@"Eu estou com dor"];
    self.inputView = self.keyboard1;
}
- (void)EnjoadoAction {
    [self.textDocumentProxy insertText:@"Eu estou enjoado"];
    self.inputView = self.keyboard1;
}

@end
