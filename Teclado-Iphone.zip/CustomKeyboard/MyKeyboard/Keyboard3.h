//
//  Keyboard3.h
//  CustomKeyboard
//
//  Created by RAFAEL FIORAMONTE on 19/10/17.
//  Copyright © 2017 MARCELO DIB COUTINHO. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Keyboard3 : UIInputView
@property (weak, nonatomic) IBOutlet UIButton *Bola;
@property (weak, nonatomic) IBOutlet UIButton *Computador;
@property (weak, nonatomic) IBOutlet UIButton *Televisao;
@property (weak, nonatomic) IBOutlet UIButton *VideoGame;


@end
